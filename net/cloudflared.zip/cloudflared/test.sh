#!/bin/sh

cloudflared --version | grep "$PKG_VERSION"
